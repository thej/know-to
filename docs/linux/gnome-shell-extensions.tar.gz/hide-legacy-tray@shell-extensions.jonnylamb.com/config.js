/* constants and stuff */

const SETTINGS_USE_TOGGLE_SHORTCUT = 'use-toggle-shortcut'
const SETTINGS_TOGGLE_SHORTCUT = 'toggle-shortcut'
